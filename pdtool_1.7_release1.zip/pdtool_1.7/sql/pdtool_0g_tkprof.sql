-- tkprof for trace from execution of tool in case someone reports slow performance in tool
HOS ls -lat &&pdtool_udump_path.*ora_&&pdtool_spid._&&pdtool_tracefile_identifier..trc >> &&pdtool_log3..txt
HOS tkprof &&pdtool_udump_path.*ora_&&pdtool_spid._&&pdtool_tracefile_identifier..trc &&pdtool_tkprof._sort.txt sort=prsela exeela fchela >> &&pdtool_log3..txt
HOS zip -j &&pdtool_zip_filename. &&pdtool_tkprof._sort.txt >> &&pdtool_log3..txt
