-- pdtool configuration parameters for oci
DEF pdtool_output_directory = '/tmp/';
DEF pdtool_host_name_separator = '.';
DEF pdtool_host_name_position = '1';
DEF pdtool_host_name_occurrence = '2';
DEF pdtool_conf_days = '61';
DEF pdtool_conf_incl_dbname_index = 'Y';
DEF pdtool_conf_incl_dbname_file = 'Y';
DEF pdtool_conf_incl_eadam = 'N';
DEF pdtool_conf_top_cur = '0';
DEF pdtool_conf_top_sig = '0';
--DEF pdtool_max_work_days_peaks = 2;
--DEF pdtool_min_work_days_peaks = 0;
--DEF pdtool_max_history_peaks = 2;
--DEF pdtool_med_history = 0;
--DEF pdtool_max_5wd_peaks = 2;
--DEF pdtool_min_5wd_peaks = 0;
--DEF pdtool_max_7d_peaks = 2;
--DEF pdtool_med_7d = 0;
DEF pdtool_conf_incl_awr_diff_rpt = 'N';
DEF skip_esp_and_escp = '--skip--';

-- sqld360 configuration parameters for bmcs
DEF sqld360_conf_incl_cboenv = 'N';
DEF sqld360_conf_incl_sqlmon = 'N';
DEF sqld360_conf_incl_ash_hist = 'N';
DEF sqld360_conf_incl_eadam = 'N';
DEF sqld360_conf_incl_rawash = 'N';
DEF sqld360_conf_incl_stats_h = 'N';
DEF sqld360_conf_incl_metadata = 'N';
DEF sqld360_conf_incl_sta = 'N';
DEF sqld360_conf_awr_timescale = 's';

-- additional transient parameters
DEF pdtool_sections = '';
