-- pdtool configuration file. for those cases where you must change pdtool functionality

/*************************** ok to modify (if really needed) ****************************/

-- section to report. null means all (default)
-- report column, or section, or range of columns or range of sections i.e. 3, 3-4, 3a, 3a-4c, 3-4c, 3c-4
DEF pdtool_sections = '1-6';

-- pdtool trace
DEF sql_trace_level = '1';

-- history days (default 31)
-- if you have an AWR retention of lets say 100 days, and want to report on 60 then pass 60
-- if you want to limit reporting to one day (who knowns why) then pass 1
DEF pdtool_conf_days = '31';

-- range of dates below superceed history days when values are other than YYYY-MM-DD
-- default values YYYY-MM-DD mean: use pdtool_conf_days
-- actual values sample: 2016-04-26
DEF pdtool_conf_date_from = 'YYYY-MM-DD';
DEF pdtool_conf_date_to = 'YYYY-MM-DD';

-- working hours are defined between these two HH24MM values (i.e. 7:30AM and 7:30PM)
-- these hours are used to categorize "user" load between 7:30 AM and 7:30 pm
-- pdtool would produce some reports looking at load during "user" time below
DEF pdtool_conf_work_time_from = '0730';
DEF pdtool_conf_work_time_to = '1930';

-- working days are defined between 1 (Sunday) and 7 (Saturday) (default Mon-Fri)
DEF pdtool_conf_work_day_from = '2';
DEF pdtool_conf_work_day_to = '6';

-- maximum time in hours to allow pdtool to execute (default 24 hrs)
DEF pdtool_conf_max_hours = '50';

-- Charts width in pixels (px) or %
DEF pdtool_chart_width = '809px'

-- include database name on index page (default N)
DEF pdtool_conf_incl_dbname_index = 'N';

-- include database name on zip filename (default N)
DEF pdtool_conf_incl_dbname_file = 'N';

-- include GV$ACTIVE_SESSION_HISTORY (default N)
DEF pdtool_conf_incl_ash_mem = 'N';

-- include GV$SQL_MONITOR (default N)
DEF pdtool_conf_incl_sql_mon = 'N';

-- include GV$SYSSTAT (default Y)
DEF pdtool_conf_incl_stat_mem = 'Y';

-- include GV$PX and GV$PQ (default Y)
DEF pdtool_conf_incl_px_mem = 'Y';

-- include DBA_SEGMENTS on queries with no filter on segment_name (default Y)
-- note: some releases of Oracle produce suboptimal plans when no segment_name is passed
DEF pdtool_conf_incl_segments = 'Y';

-- include DBA_SOURCE
-- note: applications such as EBS may take long to query such views
DEF pdtool_conf_incl_source = 'Y';

-- include DBMS_METADATA calls (default Y)
-- note: some releases of Oracle take very long to generate metadata
DEF pdtool_conf_incl_metadata = 'Y';

-- include eAdam for top SQL and peak snaps (default Y)
DEF pdtool_conf_incl_eadam = 'Y';

-- limits the size of ASH extracted by eAdam
DEF pdtool_eadam_row_limit = 10000000;

-- tool repository. set only if pdtool or eadam repository has been created
DEF tool_repo_user = '';

-- output directory for most staging files part of the zip (e.g.: "" or "./" or "/tmp/" or "/home/oracle/csierra/pdtool/prod/")
DEF pdtool_output_directory = '';

-- move generated pdtool zip file to directory (e.g.: "" or "./" or "/tmp/" or "/home/oracle/csierra/pdtool/prod/")
DEF pdtool_move_directory = '';

-- use only if you have to skip esp and escp (value --skip--) else null
--DEF skip_esp_and_escp = '--skip--';
DEF skip_esp_and_escp = '';

-- use if you need tool to act on a dbid stored on AWR, but that is not the current v$database.dbid
DEF pdtool_config_dbid = '';

-- the following 3 allow the display of host_name suffix on charts
-- for example, to display ad2.r1 when host_name is iod-db-kiev-02008.node.ad2.r1, set them to 
-- separator = '.', position = '1' and occurrence = '2'
-- when all 3 are null then host_name suffix remains null
DEF pdtool_host_name_separator = '';
DEF pdtool_host_name_position = '';
DEF pdtool_host_name_occurrence = '';

/**************************** not recommended to modify *********************************/

-- excluding report types reduce usability while providing marginal performance gain
DEF pdtool_conf_incl_html = 'Y';
DEF pdtool_conf_incl_xml  = 'N';
DEF pdtool_conf_incl_text = 'N';
DEF pdtool_conf_incl_csv  = 'N';
DEF pdtool_conf_incl_line = 'Y';
DEF pdtool_conf_incl_pie  = 'Y';
DEF pdtool_conf_incl_bar  = 'Y';

-- excluding awr reports substantially reduces usability with minimal performance gain
DEF pdtool_conf_incl_perfhub = 'N'; -- Perfhub no longer works in 12.1 due to end-of-life for flash and it is included in the AWR report in html format anyway. 
DEF pdtool_conf_incl_awr_rpt = 'Y';
DEF pdtool_conf_incl_awr_diff_rpt = 'Y'; 
DEF pdtool_conf_incl_awr_range_rpt = 'N';
DEF pdtool_conf_incl_addm_rpt = 'N';
DEF pdtool_conf_incl_ash_rpt = 'N';
DEF pdtool_conf_incl_ash_analy_rpt = 'N';
DEF pdtool_conf_incl_tkprof = 'Y';

DEF pdtool_conf_incl_plot_awr ='N'; 
DEF pdtool_conf_series_selection ='N';

-- up to how many max peaks to consider for reports for entire history work days (between 0 and 3)
DEF pdtool_max_work_days_peaks = 3;
-- consider min peaks for entire history work days reports? (0 or 1)
DEF pdtool_min_work_days_peaks = 1;
-- up to how many max peaks to consider for reports for entire history (between 0 and 3)
DEF pdtool_max_history_peaks = 3;
-- consider median for entire history reports? (0 or 1)
DEF pdtool_med_history = 1;
-- up to how many max peaks to consider for reports for last 5 work days (between 0 and 3)
DEF pdtool_max_5wd_peaks = 3;
-- consider min peaks for last 5 work days reports? (0 or 1)
DEF pdtool_min_5wd_peaks = 1;
-- up to how many max peaks to consider for reports for last 7 days (between 0 and 3)
DEF pdtool_max_7d_peaks = 3;
-- consider median for last 7 days reports? (0 or 1)
DEF pdtool_med_7d = 1;

-- top sql to execute further diagnostics (range 0-128)
DEF pdtool_conf_top_sql = '16';
DEF pdtool_conf_top_cur = '2';
DEF pdtool_conf_top_sig = '2';
DEF pdtool_conf_planx_top = '16';
DEF pdtool_conf_sqlmon_top = '0';
DEF pdtool_conf_sqlash_top = '0';
DEF pdtool_conf_sqlhc_top = '0';
DEF pdtool_conf_sqld360_top = '8';
DEF pdtool_conf_sqld360_top_tc = '0';

-- Multitenant 
/* 
* pdtool_conf_dd_mode 
Allows to run pdtool over different dictionary views depending on their prefix.
Valid values are DBA_HIST, CDB_HIST, AWR_ROOT, AWR_PDB, AWR_CDB, & AUTO
AUTO choice is: 
- DBA_HIST on non-multitenant
- AWR_ROOT on multitenant executing from CDB$ROOT in 12.2
- AWR_CDB  on multitenant executing from CDB$ROOT in 18c+
- AWR_PDB  on multitenant executing from PDB 

* pdtool_conf_con_option 
Allows to add the CON keyword to the name of the view.
Valid values are N , Y , A
Example 
pdtool_conf_con_option | View name 
            N          | cdb_hist_sysstat
            Y          | cdb_hist_con_sysstat
"A"uto choice is:
- N on pre-12.2
- N on multitenant when executing from CDB$ROOT 
- N on multitenant when executing from PDB and no PDB snapshots found
- Y on multitenant when PDB snapshots found

* pdtool_conf_is_cdb 
- A autodetect (Y if DB is multitenant. N otheriwse)
- N Assume this is not a multitenant database
- Y Assume this is a multitenant database. 

There is no guarantee that all queries will execute successfully for all values and combinations.
*/
DEF pdtool_conf_dd_mode = 'AUTO'
DEF pdtool_conf_con_option = 'A'
DEF pdtool_conf_is_cdb = 'A'
/*********************************** must match repo ************************************/

-- prefix for AWR "dba_hist_" views
DEF tool_prefix_1 = 'dba_hist#';
-- prefix for data dictionary "dba_" views
DEF tool_prefix_2 = 'dba#';
-- prefix for dynamic "gv$" views
DEF tool_prefix_3 = 'gv#';
-- prefix for dynamic "v$" views
DEF tool_prefix_4 = 'v#';

/************************************ modifications *************************************/

-- If you need to modify any parameter create a new custom configuration file with a
-- subset of the DEF above, and place on same pdtool-master/sql directory; then when
-- you execute pdtool.sql, pass on second parameter the name of your configuration file

