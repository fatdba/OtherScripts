SET HEA OFF LINES 500 PAGES 0;
SPO gather_stats_awr.sql;
SELECT 'EXEC DBMS_STATS.GATHER_TABLE_STATS(''SYS'','''||table_name||''',force=>TRUE);'
  FROM dba_tables
 WHERE owner = 'SYS'
   AND table_name LIKE 'WR_$%'
 ORDER BY
       table_name
/
SPO OFF;
SET HEA ON LINES 80 PAGES 24;
SET ECHO ON;
@gather_stats_awr.sql
