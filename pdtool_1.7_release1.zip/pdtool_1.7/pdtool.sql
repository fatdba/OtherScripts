DEF ash_validation = '';
@@sql/pdtool_0a_main.sql
-- list of generated files
HOS unzip -l &&pdtool_move_directory.&&pdtool_zip_filename.
PRO "End pdtool. Output: &&pdtool_move_directory.&&pdtool_zip_filename..zip"