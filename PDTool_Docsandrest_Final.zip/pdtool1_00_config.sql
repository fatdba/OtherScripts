-- pdtool1 configuration file. for those cases where you must change pdtool1 functionality

/*************************** ok to modify (if really needed) ****************************/

-- section to report. null means all (default)
-- report column, or section, or range of columns or range of sections i.e. 3, 3-4, 3a, 3a-4c, 3-4c, 3c-4
DEF pdtool1_sections = '';

-- pdtool1 trace
DEF sql_trace_level = '1';

-- history days (default 31)
-- if you have an AWR retention of lets say 100 days, and want to report on 60 then pass 60
-- if you want to limit reporting to one day (who knowns why) then pass 1
DEF pdtool1_conf_days = '31';

-- range of dates below superceed history days when values are other than YYYY-MM-DD
-- default values YYYY-MM-DD mean: use pdtool1_conf_days
-- actual values sample: 2016-04-26
DEF pdtool1_conf_date_from = 'YYYY-MM-DD';
DEF pdtool1_conf_date_to = 'YYYY-MM-DD';

-- working hours are defined between these two HH24MM values (i.e. 7:30AM and 7:30PM)
-- these hours are used to categorize "user" load between 7:30 AM and 7:30 pm
-- pdtool1 would produce some reports looking at load during "user" time below
DEF pdtool1_conf_work_time_from = '0730';
DEF pdtool1_conf_work_time_to = '1930';

-- working days are defined between 1 (Sunday) and 7 (Saturday) (default Mon-Fri)
DEF pdtool1_conf_work_day_from = '2';
DEF pdtool1_conf_work_day_to = '6';

-- maximum time in hours to allow pdtool1 to execute (default 24 hrs)
DEF pdtool1_conf_max_hours = '24';

-- include database name on index page (default N)
DEF pdtool1_conf_incl_dbname_index = 'N';

-- include database name on zip filename (default N)
DEF pdtool1_conf_incl_dbname_file = 'N';

-- include GV$ACTIVE_SESSION_HISTORY (default N)
DEF pdtool1_conf_incl_ash_mem = 'N';

-- include GV$SQL_MONITOR (default N)
DEF pdtool1_conf_incl_sql_mon = 'N';

-- include GV$SYSSTAT (default Y)
DEF pdtool1_conf_incl_stat_mem = 'Y';

-- include GV$PX and GV$PQ (default Y)
DEF pdtool1_conf_incl_px_mem = 'Y';

-- include DBA_SEGMENTS on queries with no filter on segment_name (default Y)
-- note: some releases of Oracle produce suboptimal plans when no segment_name is passed
DEF pdtool1_conf_incl_segments = 'Y';

-- include DBMS_METADATA calls (default Y)
-- note: some releases of Oracle take very long to generate metadata
DEF pdtool1_conf_incl_metadata = 'Y';

-- include eadam for top SQL and peak snaps (default Y)
DEF pdtool1_conf_incl_eadam = 'Y';

-- awr repository. set pdtool1_repo_user only if pdtool1 repository has been seeded recently
DEF pdtool1_repo_user = '';

-- move generated pdtool1 zip file to directory (i.e.: /home/oracle/csierra/pdtool1/prod/)
DEF pdtool1_move_directory = '';

/**************************** not recommended to modify *********************************/

-- excluding report types reduce usability while providing marginal performance gain
DEF pdtool1_conf_incl_html = 'Y';
DEF pdtool1_conf_incl_xml  = 'N';
DEF pdtool1_conf_incl_text = 'N';
DEF pdtool1_conf_incl_csv  = 'N';
DEF pdtool1_conf_incl_line = 'Y';
DEF pdtool1_conf_incl_pie  = 'Y';
DEF pdtool1_conf_incl_bar  = 'Y';

-- excluding awr reports substantially reduces usability with minimal performance gain
DEF pdtool1_conf_incl_awr_rpt = 'Y';
DEF pdtool1_conf_incl_awr_diff_rpt = 'Y';
DEF pdtool1_conf_incl_addm_rpt = 'Y';
DEF pdtool1_conf_incl_ash_rpt = 'Y';
DEF pdtool1_conf_incl_ash_analy_rpt = 'Y';
DEF pdtool1_conf_incl_tkprof = 'Y';

-- top sql to execute further diagnostics (range 0-128)
DEF pdtool1_conf_top_sql = '48';
DEF pdtool1_conf_top_cur = '4';
DEF pdtool1_conf_top_sig = '4';
DEF pdtool1_conf_planx_top = '48';
DEF pdtool1_conf_sqlmon_top = '0';
DEF pdtool1_conf_sqlash_top = '0';
DEF pdtool1_conf_sqlhc_top = '0';
DEF pdtool1_conf_pdtool11_top = '16';
DEF pdtool1_conf_pdtool11_top_tc = '0';

-- change only if you changed it while generating repository, as they must match
DEF pdtool1_repo_prefix = 'pdtool1_';

/************************************ modifications *************************************/

-- If you need to modify any parameter create a new custom configuration file with a
-- subset of the DEF above, and place on same pdtool1-master/sql directory; then when
-- you execute pdtool1.sql, pass on second parameter the name of your configuration file

-- include DBA_SEGMENTS on queries with no filter on segment_name (default Y)
-- note: some releases of Oracle produce suboptimal plans when no segment_name is passed
